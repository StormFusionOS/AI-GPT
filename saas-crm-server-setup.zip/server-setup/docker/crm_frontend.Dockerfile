# Build -> serve static with nginx
# Target 'dev' exposes node environment for Vite dev server
ARG NODE_VERSION=20

FROM node:${NODE_VERSION}-alpine AS dev
WORKDIR /app
COPY crm/package.json crm/package.json
COPY crm/ .
ARG VITE_API_BASE_URL=/
ENV VITE_API_BASE_URL=${VITE_API_BASE_URL}
RUN npm install

FROM node:${NODE_VERSION}-alpine AS build
WORKDIR /app
COPY --from=dev /app /app
RUN npm run build

FROM nginx:1.27-alpine
COPY --from=build /app/dist/ /usr/share/nginx/html/
# Vite SPA routing support
RUN printf 'server { listen 80; root /usr/share/nginx/html; index index.html; location / { try_files $uri /index.html; } }
' > /etc/nginx/conf.d/default.conf
EXPOSE 80

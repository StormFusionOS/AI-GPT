# Build and run the Ops FastAPI service + Celery (worker uses same image)
FROM python:3.11-slim

ENV PIP_DISABLE_PIP_VERSION_CHECK=1     PYTHONDONTWRITEBYTECODE=1     PYTHONUNBUFFERED=1     POETRY_VIRTUALENVS_CREATE=false

RUN apt-get update && apt-get install -y --no-install-recommends     build-essential curl ca-certificates     && rm -rf /var/lib/apt/lists/*

RUN pip install --no-cache-dir poetry

WORKDIR /app

# Install dependencies first
COPY ops_api/pyproject.toml ops_api/poetry.lock* ./
RUN poetry install --no-interaction --no-ansi --only main

# Copy the service code
COPY ops_api/ /app/

EXPOSE 8001
HEALTHCHECK --interval=10s --timeout=5s --retries=10 CMD curl -f http://localhost:8001/health || exit 1

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8001"]

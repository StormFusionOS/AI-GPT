# Build -> serve static with nginx
# Target 'dev' exposes node environment for Vite dev server
ARG NODE_VERSION=20

FROM node:${NODE_VERSION}-alpine AS dev
WORKDIR /app
COPY ops-console/package.json ops-console/package.json
COPY ops-console/ .
ARG VITE_OPS_API_URL=/ops-api/api/v1
ENV VITE_OPS_API_URL=${VITE_OPS_API_URL}
RUN npm install

FROM node:${NODE_VERSION}-alpine AS build
WORKDIR /app
COPY --from=dev /app /app
RUN npm run build -- --base=/ops/

FROM nginx:1.27-alpine
COPY --from=build /app/dist/ /usr/share/nginx/html/
RUN printf 'server { listen 80; root /usr/share/nginx/html; index index.html; location / { try_files $uri /index.html; } }
' > /etc/nginx/conf.d/default.conf
EXPOSE 80

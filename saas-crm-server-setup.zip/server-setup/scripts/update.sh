#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="../AI-GPT-codex-set-up-project-structure-for-monorepo"

if [ ! -d "$REPO_DIR/.git" ]; then
  echo "Repo not found at $REPO_DIR. Adjust the path in scripts/update.sh"
  exit 1
fi

pushd "$REPO_DIR"
git pull --ff-only
popd

docker compose --env-file ./.env up -d --build

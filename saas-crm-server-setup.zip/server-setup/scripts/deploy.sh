#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo ".env is missing. Copy .env.example to .env and edit it."
  exit 1
fi

docker compose --env-file ./.env --profile core up -d --build

echo "Run DB migrations on first boot:"
echo "  docker compose --env-file ./.env exec crm-api alembic upgrade head"
echo "  docker compose --env-file ./.env exec ops-api alembic upgrade head"

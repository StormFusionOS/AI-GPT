# SaaS/CRM Test Server — One-Box Setup

This bundle gives you a reproducible way to run your monorepo (`crm_api`, `ops_api`, `crm` React app, and `ops-console`) on a single Linux box using Docker Compose. It also includes:
- Reverse proxy (Nginx) that routes **/api** calls to the right backend and serves the front-ends
- Databases (two Postgres instances) and Redis
- Optional Celery worker for ops tasks
- Optional **Watchtower** for auto-updates when new Docker images are pushed
- Optional **Ollama + Open WebUI** so you can interact with a small local LLM on the same server
- Optional **Dozzle** (web UI to see Docker logs) and **pgAdmin** (web UI for Postgres)

> ✅ You can start with **just the core** services, then enable extras by uncommenting lines or running with compose profiles.

---

## 0) Prereqs on the Linux box
Ubuntu Server 22.04+ (or Debian 12+), 2+ CPU cores, 8 GB RAM minimum recommended for smooth dev; for LLM `llama3.2:3b`, 8 GB total RAM is fine, for `8b` models 16 GB is recommended.

Install Docker & Compose:
```bash
sudo bash scripts/install_docker.sh
```

(If you prefer manual: install Docker Engine & Docker Compose v2, then `sudo usermod -aG docker $USER` and log out/in.)

---

## 1) Put this folder on the server
Copy this whole `server-setup/` folder next to **your monorepo** clone. Recommended layout:
```
/srv/ai-crm/
├─ AI-GPT-codex-set-up-project-structure-for-monorepo/   # your repo root
└─ server-setup/                                         # this bundle
```

> You can name the parent `/srv/ai-crm/` anything you like. Just keep `server-setup` and the repo side by side.

---

## 2) Create the .env from template
```bash
cd server-setup
cp .env.example .env
# Edit .env and set secrets, domains, and passwords
```

If you’re testing only on your LAN, set:
```
PUBLIC_DOMAIN=localhost
CRM_ALLOWED_ORIGINS=http://localhost
OPS_ALLOWED_ORIGINS=http://localhost
```

---

## 3) Build and start (core only)
```bash
docker compose --env-file ./.env -f docker-compose.yml --profile core up -d --build
```

- Visit **http://SERVER_IP/** → CRM web app
- Visit **http://SERVER_IP/ops** → Ops console
- APIs are proxied under `/api` and `/ops-api` respectively. OpenAPI docs at `/api/docs` and `/ops-api/docs`.

Run database migrations (first time):
```bash
# CRM API
docker compose --env-file ./.env exec crm-api alembic upgrade head
# Ops API
docker compose --env-file ./.env exec ops-api alembic upgrade head
```

---

## 4) Hot reload (optional, for iterative UI work)
For live reload while editing code on the server, use the `dev` profile:
```bash
docker compose --env-file ./.env -f docker-compose.yml --profile dev up -d --build
```
This runs Vite dev servers and FastAPI with `--reload` (not for production).

---

## 5) Easy updates (manual)
To pick up latest code from `main` and rebuild:
```bash
cd ../AI-GPT-codex-set-up-project-structure-for-monorepo
git pull
cd ../server-setup
docker compose --env-file ./.env up -d --build
```

---

## 6) Auto updates (CI + Watchtower, optional)
1. Add `ci/ghcr-build-and-push.yml` to **.github/workflows/** in your repo.
2. Push to `main`. GitHub will build/push images to GHCR (`ghcr.io/<OWNER>/<REPO>-*`).
3. On the server, **login to GHCR** once (for private repos): `docker login ghcr.io`.
4. Enable Watchtower profile:
   ```bash
   docker compose --env-file ./.env --profile core --profile watch up -d
   ```
   Watchtower will pull new tags and restart containers automatically.

---

## 7) Local LLM (optional)
Enable the `llm` profile to run **Ollama** and **Open WebUI** on the box:
```bash
docker compose --env-file ./.env --profile core --profile llm up -d
```
- Open WebUI: `http://SERVER_IP:8080`
- Pull a small model once inside the `ollama` container or on the host:
  ```bash
  docker exec -it ollama ollama pull llama3.2:3b
  ```

You can call it from your backends at `http://ollama:11434` (see **Examples** at end of this file).

---

## 8) Troubleshooting
- See container status: `docker compose ps`
- Logs for everything via Dozzle (optional): enable `ui` profile and visit `http://SERVER_IP:9999`
- Tail a specific service: `docker compose logs -f crm-api`
- Check Postgres with pgAdmin (optional `ui` profile): `http://SERVER_IP:5050`

---

## 9) Stop / remove
```bash
docker compose down        # stop
docker compose down -v     # stop and remove volumes (DBs will be wiped)
```

---

## Example: calling Ollama from FastAPI
```python
import httpx
from fastapi import APIRouter

router = APIRouter()

@router.post("/llm/ask")
async def ask_llm(prompt: str):
    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(
            "http://ollama:11434/api/generate",
            json={"model": "llama3.2:3b", "prompt": prompt, "stream": False},
        )
    return r.json()
```

---

## Notes
- This is **not** a production-hardening guide; it’s a single-box test rig. For HTTPS on the public internet, either put this behind a Cloudflare Tunnel or swap Nginx for Caddy/Traefik and add ACME (Let’s Encrypt).
- If your server is slow, disable optional profiles and run only the core.

---

## Using image-based deployments tied to your GitHub repo

To let the server auto-update on every push to **https://github.com/StormFusionOS/AI-GPT**:

1) In *your repo*, add:
   - `server-setup/docker/` (from this bundle)
   - `.github/workflows/ghcr-build-and-push.yml` (from this bundle)

2) Commit & push. The workflow builds and pushes images to **ghcr.io**:
   - `ghcr.io/stormfusionos/ai-gpt-crm-api:latest`
   - `ghcr.io/stormfusionos/ai-gpt-ops-api:latest`
   - `ghcr.io/stormfusionos/ai-gpt-crm-frontend:latest`
   - `ghcr.io/stormfusionos/ai-gpt-ops-frontend:latest`

3) On the server:
   ```bash
   cd server-setup
   echo 'IMAGE_PREFIX=stormfusionos/ai-gpt' | tee -a .env
   docker login ghcr.io   # use a PAT with read:packages if repo is private
   docker compose --env-file ./.env -f docker-compose.images.yml --profile core --profile watch up -d
   ```
